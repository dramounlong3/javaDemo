export BATCH1_DATABASE_PWD=$(/data/atomic/pwd_encrypt --ciphertext $BATCH1_DATABASE_PASSWORD)
export BATCH2_DATABASE_PWD=$(/data/atomic/pwd_encrypt --ciphertext $BATCH2_DATABASE_PASSWORD)
export KERNEL_DATABASE_PWD=$(/data/atomic/pwd_encrypt --ciphertext $KERNEL_DATABASE_PASSWORD)
exec npm start --cache /data/atomic/.npm -- --userDir /data/atomic /data/atomic/flows.json
