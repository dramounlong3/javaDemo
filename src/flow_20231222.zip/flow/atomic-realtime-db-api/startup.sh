export REALTIME1_DB_PWD=$(/data/atomic/pwd_encrypt --ciphertext $REALTIME1_DATABASE_PASSWORD)
export REALTIME2_DB_PWD=$(/data/atomic/pwd_encrypt --ciphertext $REALTIME2_DATABASE_PASSWORD)
export REPORT_DB_PWD=$(/data/atomic/pwd_encrypt --ciphertext $REPORT_DATABASE_PASSWORD)
exec npm start --cache /data/atomic/.npm -- --userDir /data/atomic /data/atomic/flows.json
