export CACHE1_DATABASE_PWD=$(/data/atomic/pwd_encrypt --ciphertext $CACHE1_DATABASE_PASSWORD)
export CACHE2_DATABASE_PWD=$(/data/atomic/pwd_encrypt --ciphertext $CACHE2_DATABASE_PASSWORD)
export REPORT_DATABASE_PWD=$(/data/atomic/pwd_encrypt --ciphertext $REPORT_DATABASE_PASSWORD)
exec npm start --cache /data/atomic/.npm -- --userDir /data/atomic /data/atomic/flows.json
