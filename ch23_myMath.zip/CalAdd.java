package myMath;

public class CalAdd {
    public int add (int para1, int para2) {
        return para1 + para2;
    }
}
