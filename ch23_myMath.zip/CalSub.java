package myMath.subMath;

public class CalSub {
    public int subtract (int para1, int para2) {
        return para2 - para1;
    }
}
