package myMath;

public class CalMul {
    public int mul(int para1, int para2) {
        return para1 * para2;
    }
}
